function [ c ] = kpClassify( XTrain, XTest, w, d )
    % Filler code, replace with your own.
    nTest = size(XTest,1);
    c = zeros(nTest,1);
end

