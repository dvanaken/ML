function [ Feats ] = mail2Feat( Mail )
    nMail = size(Mail,1);
    
    function word = snip(startword)
       if startword(end)=='s'
          startword = startword(1:end-1); 
       end
       word = startword;
    end
    

    % THE FOLLOWING IS A VERY SIMPLE EXAMPLE SHOWING ONE POSSIBLE WAY TO
    % COLLECT FEATURES. PLEASE REPLACE WITH YOUR CODE. NOTE HOW YOU CAN PLACE
    % PRE-PROCESSED RESULTS IN dictionary.csv.
    % NOTE: commented out for speed while testing previous exercises.

    % load data from dictionary.csv file
    fid = fopen('dictionary.csv');    
    tline = fgetl(fid);
    [features,props] = strread(tline,'%s %f','delimiter',',');
    nFeats = length(props);
    Feats = zeros(nMail,nFeats); 
    for n=1:nMail
        thisMail = Mail{n};
        nWordCells = length(thisMail);
        words = [];
        for i=1:nWordCells
            % Remove punctuation, digits, etc.
            C = regexp(thisMail{i}, '[^A-Za-z]', 'split');
            % Remove empty cells
            C=C(~cellfun('isempty',C));
            % Make everything lowercase
            C=lower(C);
            C = cellfun(@snip,C,'UniformOutput', false);
            words = horzcat(words,C);
        end
        for i=1:nFeats
            Feats(n,i) = sum(strcmp(words,features{i}))*props(i); 
        end
    end
end

