function [ w ] = kpWeights( XTrain, yTrain, nIter, d )
    % Filler code, replace with your own.
    nTrain = size(XTrain,1);
    w = zeros(nTrain,1);
end

